import logo from "@/assets/crimson-tree.png";
import { useState } from "react";
import {
  NavigationMenu,
  NavigationMenuItem,
  NavigationMenuList,
} from "@/components/ui/navigation-menu";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { buttonVariants } from "./ui/button";
import { Menu } from "lucide-react";
import { ModeToggle } from "./mode-toggle";

interface RouteProps {
  href: string;
  label: string;
}

const routeList: RouteProps[] = [
  { href: "#about", label: "About" },
  { href: "#academics", label: "Academics" },
  { href: "#student-life", label: "Student Life" },
  { href: "#results", label: "Results" },
  { href: "#give", label: "Give" },
];

export const Navbar = () => {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  return (
    <header className="sticky border-b top-0 z-40 w-full bg-background/85 backdrop-blur supports-[backdrop-filter]:bg-background/70">
      <NavigationMenu className="mx-auto">
        <NavigationMenuList className="container h-16 px-4 w-screen flex justify-between items-center">
          <NavigationMenuItem className="font-bold flex">
            <a href="/" className="flex items-center gap-2 font-heading font-bold text-lg">
              <img src={logo} alt="Crimson Academy crest" className="h-9 w-9 object-contain" />
              <span className="leading-none">
                Crimson <span className="text-primary">Academy</span>
              </span>
            </a>
          </NavigationMenuItem>

          {/* mobile */}
          <span className="flex md:hidden items-center gap-2">
            <ModeToggle />
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger className="px-2">
                <Menu className="h-5 w-5" onClick={() => setIsOpen(true)} aria-label="Open menu" />
              </SheetTrigger>
              <SheetContent side="left">
                <SheetHeader>
                  <SheetTitle className="font-heading text-xl flex items-center gap-2">
                    <img src={logo} alt="" className="h-7 w-7 object-contain" />
                    Crimson Academy
                  </SheetTitle>
                </SheetHeader>
                <nav className="flex flex-col gap-2 mt-6">
                  {routeList.map(({ href, label }) => (
                    <a key={label} href={href} onClick={() => setIsOpen(false)}
                      className={buttonVariants({ variant: "ghost" })}>
                      {label}
                    </a>
                  ))}
                  <a href="#admissions" onClick={() => setIsOpen(false)}
                    className={buttonVariants({ variant: "default" })}>
                    Apply Now
                  </a>
                </nav>
              </SheetContent>
            </Sheet>
          </span>

          {/* desktop */}
          <nav className="hidden md:flex gap-1">
            {routeList.map(({ href, label }) => (
              <a key={label} href={href}
                className={`text-sm ${buttonVariants({ variant: "ghost" })}`}>
                {label}
              </a>
            ))}
          </nav>

          <div className="hidden md:flex gap-2 items-center">
            <ModeToggle />
            <a href="#admissions" className={buttonVariants({ variant: "default" })}>
              Apply Now
            </a>
          </div>
        </NavigationMenuList>
      </NavigationMenu>
    </header>
  );
};
