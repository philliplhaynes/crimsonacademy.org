import logo from "@/assets/crimson-tree.png";
import { MapPin, Mail, Globe } from "lucide-react";

export const Footer = () => {
  return (
    <footer id="contact" className="border-t bg-secondary/40">
      <div className="container py-14 grid md:grid-cols-4 gap-10">
        <div className="space-y-3">
          <a href="/" className="flex items-center gap-2 font-heading font-bold text-lg">
            <img src={logo} alt="" className="h-9 w-9 object-contain" />
            Crimson Academy
          </a>
          <p className="text-sm text-muted-foreground">
            Faith, character, and academic excellence in Kagina, Rwanda.
          </p>
        </div>

        <div>
          <h4 className="font-heading font-semibold mb-3">Explore</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li><a href="#about" className="hover:text-primary">About</a></li>
            <li><a href="#academics" className="hover:text-primary">Academics</a></li>
            <li><a href="#student-life" className="hover:text-primary">Student Life</a></li>
            <li><a href="#admissions" className="hover:text-primary">Admissions</a></li>
            <li><a href="#give" className="hover:text-primary">Give</a></li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading font-semibold mb-3">Contact</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-start gap-2"><MapPin className="h-4 w-4 mt-0.5 shrink-0" /> Kagina, Kamonyi District, Southern Province, Rwanda</li>
            <li className="flex items-center gap-2"><Mail className="h-4 w-4 shrink-0" /> info@crimsonacademy.org</li>
            <li className="flex items-center gap-2"><Globe className="h-4 w-4 shrink-0" /> English · Français · Kinyarwanda</li>
          </ul>
        </div>

        <div>
          <h4 className="font-heading font-semibold mb-3">Partners</h4>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li>Crimson Foundation</li>
            <li>Jenzabar Foundation</li>
          </ul>
          <a href="#" className="inline-block mt-4 text-sm text-primary font-medium underline underline-offset-4">Parent / Staff Portal</a>
        </div>
      </div>
      <div className="border-t">
        <div className="container py-6 flex flex-col sm:flex-row justify-between gap-3 text-xs text-muted-foreground">
          <span>© {new Date().getFullYear()} Crimson Academy of Kagina. All rights reserved.</span>
          <span className="flex gap-4">
            <a href="#" className="hover:text-primary">Privacy</a>
            <a href="#" className="hover:text-primary">Child Safeguarding</a>
          </span>
        </div>
      </div>
    </footer>
  );
};
