import logo from "@/assets/crimson-tree.png";
import { buttonVariants } from "./ui/button";
import { ArrowRight, MapPin } from "lucide-react";

export const Hero = () => {
  return (
    <section className="container grid lg:grid-cols-2 place-items-center py-16 md:py-28 gap-12">
      <div className="text-center lg:text-start space-y-6">
        <div className="inline-flex items-center gap-2 rounded-full border border-accent/40 bg-accent/10 px-4 py-1.5 text-xs font-medium tracking-wide uppercase text-accent-foreground">
          <MapPin className="h-3.5 w-3.5" /> Kagina · Kamonyi District, Rwanda
        </div>

        <h1 className="font-heading text-4xl md:text-6xl font-semibold leading-[1.05]">
          Where <span className="text-primary">faith</span> and{" "}
          <span className="text-primary">academic excellence</span> grow together.
        </h1>

        <p className="text-lg text-muted-foreground md:w-11/12 mx-auto lg:mx-0">
          Crimson Academy of Kagina is a Christian primary school educating over 780
          children — and, year after year, the #1 school in Rwanda&apos;s Southern
          Province on the National Exams.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center lg:justify-start">
          <a href="#admissions" className={buttonVariants({ variant: "default" })}>
            Apply for Admission <ArrowRight className="ml-2 h-4 w-4" />
          </a>
          <a href="#give" className={buttonVariants({ variant: "outline" })}>
            Sponsor a Student
          </a>
        </div>

        <p className="text-sm text-muted-foreground">
          Taught in <span className="font-medium text-foreground">English, French &amp; Kinyarwanda</span> · Nursery through Primary 6
        </p>
      </div>

      <div className="relative z-10 flex justify-center">
        <div className="absolute inset-0 -z-10 rounded-full bg-primary/10 blur-3xl" />
        <img
          src={logo}
          alt="Crimson Academy oak-tree crest"
          className="w-64 md:w-96 object-contain drop-shadow-2xl"
        />
      </div>

      <div className="shadow"></div>
    </section>
  );
};
